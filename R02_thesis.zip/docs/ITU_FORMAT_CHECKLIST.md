\## THESIS TITLE CONSISTENCY



The thesis title shall be identical everywhere:



\* Cover page

\* Inner cover page

\* Approval page

\* Turkish abstract

\* English summary

\* Metadata

\* PDF bookmarks (if applicable)



The title shall be fully uppercase in all preliminary pages.



Examples:



WRONG:

24–30 GHz



CORRECT:

24–30 GHZ



\---



\## COVER PAGE INTEGRITY



The cover page shall fit entirely on a single page.



The following items shall appear on the same page:



\* Thesis title

\* Thesis type

\* Author name

\* Department

\* Programme

\* Month and year



No cover-page element may overflow to a second page.



\---



\## COVER PAGE GEOMETRY



Verify against the official ITU template:



\* Title position

\* Title line breaks

\* Title font size

\* Thesis type position

\* Author position

\* Department position

\* Programme position

\* Date position



Text correctness alone is insufficient.



\---



\## ABSTRACT LENGTH CONTROL



For English thesis:



SUMMARY:



\* 1–3 pages



ÖZET:



\* 3–5 pages



Page count shall be verified from the final PDF.



\---



\## ABSTRACT QUALITY CONTROL



Verify:



\* Natural writing style

\* No obvious padding

\* No repetitive sentences

\* No artificially extended paragraphs



The abstract shall read as a coherent technical summary.



\---



\## TABLE OVERFLOW CHECK



Verify every table in rendered PDF.



Forbidden:



\* Clipped cells

\* Clipped text

\* Content outside margins

\* Content outside text block



\---



\## HEADING ORPHAN CHECK



Forbidden:



\* Section heading at page bottom

\* Subsection heading at page bottom

\* Heading followed by fewer than two lines of text



\---



\## FIGURE ORPHAN CHECK



Forbidden:



\* Figure number separated from figure

\* Caption separated from figure

\* Figure isolated at page boundary



\---



\## TABLE ORPHAN CHECK



Forbidden:



\* Table caption separated from table

\* Table number isolated

\* Table split without explanation



\---



\## TOC / LOF / LOT FORMATTING



Verify:



\* Line spacing

\* Alignment

\* Page numbering

\* Indentation hierarchy



against official ITU template.



\---



\## SUPERVISOR INFORMATION



Verify exact title:



Doç. Dr. Nil Banu TARIM



No alternative titles permitted.



\---



\## TERMINOLOGY CONSISTENCY



Forbidden:



\* uyumlama ağı

\* kademe

\* yığın transistor

\* yığın yapı



Preferred:



\* uyumlama devresi

\* kat

\* kaskot transistor

\* kaskot yapı



\---



\## PDF RENDER REVIEW



The following pages shall be visually inspected:



\* Cover page

\* Inner cover

\* Approval page

\* Contents

\* List of Figures

\* List of Tables

\* Summary

\* Özet

\* Chapter opening pages

\* References

\* Appendices

\* CV



Text extraction alone is insufficient.



\---



\## FINAL PRE-SUBMISSION REVIEW



Verify:



\* No title inconsistencies

\* No page overflow

\* No table overflow

\* No figure overflow

\* No heading orphan

\* No widow/orphan text

\* No broken references

\* No broken citations

\* No duplicated content

\* No placeholder text

\* No TODO comments



```



Bence bunlar artık bizim \*\*tez özelinde keşfettiğimiz gerçek hata listesi\*\*. Bundan sonra yeni bir hata yakalarsak önce bunu checklist'e ekleyeceğiz, sonra tezi düzelteceğiz. Böylece aynı hata ikinci kez kaçmayacak.

```



