# THESIS_TASKS.md

Purpose: Active thesis development tasks. Completed tasks shall be removed after integration.

## THESIS CONSTANTS
Student ID: 504231213
Advisor: Doç. Dr. Nil Banu TARIM
Language: English

## RF TERMINOLOGY
Always use:
- matching network -> matching circuit
- uyumlama ağı -> uyumlama devresi
- stage -> kat
- kademe -> kat
- stacked -> kaskot
- yığın/yığınlı -> kaskot

# OPEN TASKS

## FIGURES
- [ ] Insert literature figure for conventional T/R switch-based front-end topology.
- [ ] Insert literature figure for shared-path bidirectional front-end topology.
- [ ] Insert literature figure for capacitive neutralization / neutralized bidirectional core.
- [ ] Verify citation requirements for all imported figures.

## STATE-OF-THE-ART TABLE
- [ ] Replace TBD entries for this work after final TX-mode values are fixed.
- [ ] Re-check all table values against final selected references before submission.

## REFERENCES
- [ ] Remove unused references after final Chapter 1 and Chapter 2 review.

## COMPLETED TASKS
(empty)
